# Change Log
<pre>
v2.0.0  Fixed methods deprecated in iOS 7 [MOD-1521]
        Add Support for iOS7 MapCamera [MOD-1523]
        Expose new iOS7 properties and methods of MapView [MOD-1522]

v1.0.0  Moved out of the Titanium SDK to a standalone module [MOD-1514]